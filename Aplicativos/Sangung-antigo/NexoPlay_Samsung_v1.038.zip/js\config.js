var NEXO_CONFIG = {
    appName: "Nexo Play",
    version: "1.038-legacy-json-jsdelivr-main",
    accessCodeUrl: "https://nexoplay88.github.io/app/Aplicativos/dns-codigos/nexo_play_codigos.json",
    requestTimeout: 10000,
    searchTimeout: 35000,
    serverTimeout: 7500,
    homeItemLimit: 5,
    catalogItemLimit: 60
};
